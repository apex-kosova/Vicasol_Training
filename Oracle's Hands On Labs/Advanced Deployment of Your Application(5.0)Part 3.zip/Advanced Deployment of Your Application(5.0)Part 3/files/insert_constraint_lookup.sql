insert into CONSTRAINT_LOOKUP
  (CONSTRAINT_NAME, MESSAGE)
values
  ('DEPT_DNAME_UK', 'Name is already in use!');