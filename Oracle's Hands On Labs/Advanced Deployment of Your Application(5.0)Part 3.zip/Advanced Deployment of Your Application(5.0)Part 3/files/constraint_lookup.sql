create table CONSTRAINT_LOOKUP
(
  CONSTRAINT_NAME VARCHAR2(30)   primary key,
  MESSAGE         VARCHAR2(4000) not null
);