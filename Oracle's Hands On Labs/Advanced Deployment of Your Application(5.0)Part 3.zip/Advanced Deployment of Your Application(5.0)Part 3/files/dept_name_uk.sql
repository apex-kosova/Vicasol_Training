alter table DEPARTMENTS
add constraint DEPT_DNAME_UK unique (DEPARTMENT_NAME);
